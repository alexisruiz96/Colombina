var Module = {};
importScripts('CVBridge.js', 'worker2.js');
postMessage({msg: 'asm'});
postMessage({msg: 'asm'});
